// lib/services/storage_service.dart
// خدمة التخزين — رفع الفيديوهات والصور إلى Firebase Storage

import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:uuid/uuid.dart';

class StorageService {
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final _uuid = const Uuid();

  // ═══════════════════════════════════════════════════════════════════
  // 1. رفع الفيديو (مع تتبع التقدم)
  // ═══════════════════════════════════════════════════════════════════
  Future<String?> uploadVideo({
    required File file,
    required String userId,
    Function(double progress)? onProgress,
  }) async {
    try {
      final id = _uuid.v4();
      final ref = _storage.ref().child('videos/$userId/$id.mp4');
      
      final uploadTask = ref.putFile(file);

      // تتبع نسبة الرفع (0.0 to 1.0)
      if (onProgress != null) {
        uploadTask.snapshotEvents.listen((TaskSnapshot snapshot) {
          final progress = snapshot.bytesTransferred / snapshot.totalBytes;
          onProgress(progress);
        });
      }

      final taskSnapshot = await uploadTask;
      return await taskSnapshot.ref.getDownloadURL();
    } catch (e) {
      return null;
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // 2. رفع صورة (للملف الشخصي أو الصور المصغرة)
  // ═══════════════════════════════════════════════════════════════════
  Future<String?> uploadImage({
    required File file,
    required String userId,
    String folder = 'profiles', // 'profiles' أو 'thumbnails'
  }) async {
    try {
      final id = _uuid.v4();
      final ext = file.path.split('.').last;
      final ref = _storage.ref().child('$folder/$userId/$id.$ext');
      
      final task = await ref.putFile(file);
      return await task.ref.getDownloadURL();
    } catch (e) {
      return null;
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // 3. رفع بصمة صوتية (للمحادثات)
  // ═══════════════════════════════════════════════════════════════════
  Future<String?> uploadVoice({
    required File file,
    required String userId,
  }) async {
    try {
      final id = _uuid.v4();
      final ref = _storage.ref().child('voice/$userId/$id.aac');
      
      final task = await ref.putFile(file);
      return await task.ref.getDownloadURL();
    } catch (e) {
      return null;
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // 4. حذف ملف (اختياري — للتنظيف)
  // ═══════════════════════════════════════════════════════════════════
  Future<bool> deleteFile(String url) async {
    try {
      final ref = _storage.refFromURL(url);
      await ref.delete();
      return true;
    } catch (e) {
      return false;
    }
  }
}