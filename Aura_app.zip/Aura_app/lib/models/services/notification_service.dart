// lib/services/notification_service.dart
// خدمة الإشعارات — تسجيل في Firestore وإرسال إشعارات محلية

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import '../models/notification_model.dart';

class NotificationService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _local = FlutterLocalNotificationsPlugin();

  // ═══════════════════════════════════════════════════════════════════
  // التهيئة (تُستدعى في main.dart مرة وحدة)
  // ═══════════════════════════════════════════════════════════════════
  Future<void> init() async {
    try {
      // 1. طلب صلاحية الإشعارات
      await _fcm.requestPermission(
        alert: true,
        badge: true,
        sound: true,
      );

      // 2. تهيئة الإشعارات المحلية
      const initAndroid = AndroidInitializationSettings('@mipmap/ic_launcher');
      const initIOS = DarwinInitializationSettings(
        requestAlertPermission: true,
        requestBadgePermission: true,
        requestSoundPermission: true,
      );
      const initSettings = InitializationSettings(
        android: initAndroid,
        iOS: initIOS,
      );
      
      await _local.initialize(
        initSettings,
        onDidReceiveNotificationResponse: (details) {
          // هنا تقدر تضيف كود يشتغل لما المستخدم يضغط على الإشعار
        },
      );

      // 3. الاستماع للإشعارات وهي التطبيق مفتوح (Foreground)
      FirebaseMessaging.onMessage.listen((RemoteMessage msg) {
        _showLocal(msg);
      });

      // 4. حفظ الـ FCM Token (عشان السيرفر يبعت إشعارات للجهاز)
      final token = await _fcm.getToken();
      if (token != null) {
        // تقدر تحفظه في Firestore تحت بيانات المستخدم
        // await _db.collection('users').doc(uid).update({'fcmToken': token});
      }
    } catch (e) {
      // تجاهل الخطأ إذا المستخدم رافض الصلاحيات
    }
  }

  // عرض إشعار محلي
  Future<void> _showLocal(RemoteMessage msg) async {
    try {
      const androidDetails = AndroidNotificationDetails(
        'aura_channel',
        'Aura Notifications',
        channelDescription: 'إشعارات تطبيق أورا',
        importance: Importance.high,
        priority: Priority.high,
      );
      const details = NotificationDetails(android: androidDetails);
      
      await _local.show(
        msg.hashCode,
        msg.notification?.title ?? 'Aura',
        msg.notification?.body ?? '',
        details,
      );
    } catch (e) {}
  }

  // ═══════════════════════════════════════════════════════════════════
  // إنشاء إشعار جديد (يُستدعى من FirestoreService)
  // ═══════════════════════════════════════════════════════════════════
  Future<void> createNotification({
    required String userId,       // اللي راح يوصله الإشعار
    required String actorId,      // اللي سوى الحدث
    required String actorName,
    required String actorPhoto,
    required String type,         // 'follow' | 'like' | 'comment' | 'mention'
    String? videoId,
    String? videoThumb,
    String? text,
  }) async {
    // إذا الشخص سوى الحدث على نفسه، ما نرسل إشعار
    if (userId == actorId) return;

    try {
      final id = _db.collection('notifications').doc().id;
      final notif = AppNotification(
        id: id,
        userId: userId,
        actorId: actorId,
        actorName: actorName,
        actorPhoto: actorPhoto,
        type: type,
        videoId: videoId,
        videoThumb: videoThumb,
        text: text,
        createdAt: DateTime.now(),
      );
      
      await _db.collection('notifications').doc(id).set(notif.toMap());
    } catch (e) {
      // نتجاهل الخطأ عشان ما يوقف التطبيق
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // جلب الإشعارات للمستخدم
  // ═══════════════════════════════════════════════════════════════════
  Stream<List<AppNotification>> getUserNotifications(String userId) {
    return _db
        .collection('notifications')
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .limit(50)
        .snapshots()
        .map((s) => s.docs.map((d) => AppNotification.fromMap(d.data())).toList());
  }

  // عدد الإشعارات غير المقروءة
  Stream<int> getUnreadCount(String userId) {
    return _db
        .collection('notifications')
        .where('userId', isEqualTo: userId)
        .where('read', isEqualTo: false)
        .snapshots()
        .map((s) => s.docs.length);
  }

  // تحديد إشعار كمقروء
  Future<void> markRead(String notifId) async {
    try {
      await _db.collection('notifications').doc(notifId).update({'read': true});
    } catch (e) {}
  }

  // تحديد كل الإشعارات كمقروءة
  Future<void> markAllRead(String userId) async {
    try {
      final snap = await _db
          .collection('notifications')
          .where('userId', isEqualTo: userId)
          .where('read', isEqualTo: false)
          .get();
          
      final batch = _db.batch();
      for (final doc in snap.docs) {
        batch.update(doc.reference, {'read': true});
      }
      await batch.commit();
    } catch (e) {}
  }
}