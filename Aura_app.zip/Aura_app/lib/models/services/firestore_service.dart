// lib/services/firestore_service.dart
// الخدمة الأساسية لقاعدة البيانات — فيديوهات، إعجابات، متابعة، تعليقات، بحث

import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/video_model.dart';
import '../models/comment_model.dart';
import 'notification_service.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final NotificationService _notif = NotificationService();

  // ═══════════════════════════════════════════════════════════════════
  // 1. الخوارزمية وجلب الفيديوهات
  // ═══════════════════════════════════════════════════════════════════

  // خوارزمية "لك" (For You) — ترتيب حسب الـ Score
  Stream<List<VideoModel>> getForYouFeed() {
    return _db
        .collection('videos')
        .orderBy('createdAt', descending: true)
        .limit(100)
        .snapshots()
        .map((snap) {
      final now = DateTime.now();
      final videos = snap.docs.map((d) {
        final v = VideoModel.fromMap(d.data());
        // حساب الـ score: تفاعل + عامل الوقت
        final ageHours = now.difference(v.createdAt).inHours;
        final ageFactor = 1.0 / (1.0 + ageHours / 24.0); // يقل مع الوقت
        final engagement = (v.likes * 3.0) + (v.comments * 5.0) + (v.shares * 7.0) + (v.saves * 4.0);
        final score = engagement * ageFactor;
        
        return v.copyWith(score: score);
      }).toList();
      
      // ترتيب تنازلي حسب الـ score
      videos.sort((a, b) => b.score.compareTo(a.score));
      return videos;
    });
  }

  // جلب فيديوهات المتابعين (Following Feed)
  Stream<List<VideoModel>> getFollowingFeed(String userId) {
    return _db
        .collection('users')
        .doc(userId)
        .collection('following')
        .snapshots()
        .asyncMap((snap) async {
      final ids = snap.docs.map((d) => d.id).toList();
      if (ids.isEmpty) return <VideoModel>[];

      final chunks = <List<String>>[];
      for (var i = 0; i < ids.length; i += 10) {
        chunks.add(ids.sublist(i, i + 10 > ids.length ? ids.length : i + 10));
      }

      final all = <VideoModel>[];
      for (final c in chunks) {
        final q = await _db
            .collection('videos')
            .where('userId', whereIn: c)
            .orderBy('createdAt', descending: true)
            .limit(50)
            .get();
        all.addAll(q.docs.map((d) => VideoModel.fromMap(d.data())));
      }
      
      all.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return all;
    });
  }

  // إضافة فيديو جديد
  Future<bool> addVideo(VideoModel video) async {
    try {
      await _db.collection('videos').doc(video.id).set(video.toMap());
      return true;
    } catch (e) {
      return false;
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // 2. الإعجاب (Like / Unlike)
  // ═══════════════════════════════════════════════════════════════════

  Future<bool> toggleLike(String videoId, String userId) async {
    try {
      final ref = _db.collection('videos').doc(videoId).collection('likes').doc(userId);
      final doc = await ref.get();

      if (doc.exists) {
        // إزالة الإعجاب
        await ref.delete();
        await _db.collection('videos').doc(videoId).update({'likes': FieldValue.increment(-1)});
        return false;
      } else {
        // إضافة الإعجاب
        await ref.set({'userId': userId, 'createdAt': DateTime.now().toIso8601String()});
        await _db.collection('videos').doc(videoId).update({'likes': FieldValue.increment(1)});

        // إرسال إشعار لصاحب الفيديو
        final v = await _db.collection('videos').doc(videoId).get();
        final ownerId = v.data()?['userId'] ?? '';
        
        if (ownerId != userId) {
          final actor = await _db.collection('users').doc(userId).get();
          await _notif.createNotification(
            userId: ownerId,
            actorId: userId,
            actorName: actor.data()?['username'] ?? '',
            actorPhoto: actor.data()?['photoUrl'] ?? '',
            type: 'like',
            videoId: videoId,
            videoThumb: v.data()?['thumbnailUrl'],
          );
        }
        return true;
      }
    } catch (e) {
      return false;
    }
  }

  Stream<bool> isLiked(String videoId, String userId) {
    return _db.collection('videos').doc(videoId).collection('likes').doc(userId)
        .snapshots().map((doc) => doc.exists);
  }

  // ═══════════════════════════════════════════════════════════════════
  // 3. الحفظ (Save / Unsave)
  // ═══════════════════════════════════════════════════════════════════

  Future<bool> toggleSave(String videoId, String userId) async {
    try {
      final ref = _db.collection('videos').doc(videoId).collection('saves').doc(userId);
      final doc = await ref.get();

      if (doc.exists) {
        await ref.delete();
        await _db.collection('videos').doc(videoId).update({'saves': FieldValue.increment(-1)});
        return false;
      } else {
        await ref.set({'userId': userId, 'createdAt': DateTime.now().toIso8601String()});
        await _db.collection('videos').doc(videoId).update({'saves': FieldValue.increment(1)});
        return true;
      }
    } catch (e) {
      return false;
    }
  }

  Stream<bool> isSaved(String videoId, String userId) {
    return _db.collection('videos').doc(videoId).collection('saves').doc(userId)
        .snapshots().map((doc) => doc.exists);
  }

  Stream<List<VideoModel>> getSavedVideos(String userId) {
    return _db.collectionGroup('saves')
        .where('userId', isEqualTo: userId)
        .snapshots()
        .asyncMap((snap) async {
      final ids = snap.docs.map((d) => d.reference.parent.parent!.id).toList();
      if (ids.isEmpty) return <VideoModel>[];
      
      final videos = <VideoModel>[];
      for (final id in ids) {
        final doc = await _db.collection('videos').doc(id).get();
        if (doc.exists) videos.add(VideoModel.fromMap(doc.data()!));
      }
      return videos;
    });
  }

  // ═══════════════════════════════════════════════════════════════════
  // 4. المشاركة والمشاهدة
  // ═══════════════════════════════════════════════════════════════════

  Future<void> incrementShare(String videoId) async {
    try {
      await _db.collection('videos').doc(videoId).update({'shares': FieldValue.increment(1)});
    } catch (e) {}
  }

  Future<void> incrementView(String videoId) async {
    try {
      await _db.collection('videos').doc(videoId).update({'views': FieldValue.increment(1)});
    } catch (e) {}
  }

  // ═══════════════════════════════════════════════════════════════════
  // 5. المتابعة (Follow / Unfollow)
  // ═══════════════════════════════════════════════════════════════════

  Future<bool> toggleFollow(String currentUserId, String targetUserId) async {
    try {
      final followRef = _db.collection('users').doc(currentUserId).collection('following').doc(targetUserId);
      final followerRef = _db.collection('users').doc(targetUserId).collection('followers').doc(currentUserId);
      final doc = await followRef.get();

      if (doc.exists) {
        // إلغاء المتابعة
        await followRef.delete();
        await followerRef.delete();
        await _db.collection('users').doc(currentUserId).update({'following': FieldValue.increment(-1)});
        await _db.collection('users').doc(targetUserId).update({'followers': FieldValue.increment(-1)});
        return false;
      } else {
        // متابعة جديدة
        final data = {'createdAt': DateTime.now().toIso8601String()};
        await followRef.set(data);
        await followerRef.set(data);
        await _db.collection('users').doc(currentUserId).update({'following': FieldValue.increment(1)});
        await _db.collection('users').doc(targetUserId).update({'followers': FieldValue.increment(1)});

        // إشعار
        final actor = await _db.collection('users').doc(currentUserId).get();
        await _notif.createNotification(
          userId: targetUserId,
          actorId: currentUserId,
          actorName: actor.data()?['username'] ?? '',
          actorPhoto: actor.data()?['photoUrl'] ?? '',
          type: 'follow',
        );
        return true;
      }
    } catch (e) {
      return false;
    }
  }

  Stream<bool> isFollowing(String currentUserId, String targetUserId) {
    return _db.collection('users').doc(currentUserId).collection('following').doc(targetUserId)
        .snapshots().map((doc) => doc.exists);
  }

  // ═══════════════════════════════════════════════════════════════════
  // 6. التعليقات (Comments)
  // ═══════════════════════════════════════════════════════════════════

  Future<bool> addComment({
    required String videoId,
    required String userId,
    required String username,
    required String userPhoto,
    required String text,
  }) async {
    try {
      final commentId = _db.collection('videos').doc(videoId).collection('comments').doc().id;
      
      final comment = CommentModel(
        id: commentId,
        userId: userId,
        username: username,
        userPhoto: userPhoto,
        text: text,
        createdAt: DateTime.now(),
      );

      await _db.collection('videos').doc(videoId).collection('comments').doc(commentId).set(comment.toMap());
      await _db.collection('videos').doc(videoId).update({'comments': FieldValue.increment(1)});

      // إشعار
      final v = await _db.collection('videos').doc(videoId).get();
      final ownerId = v.data()?['userId'] ?? '';
      
      if (ownerId != userId) {
        await _notif.createNotification(
          userId: ownerId,
          actorId: userId,
          actorName: username,
          actorPhoto: userPhoto,
          type: 'comment',
          videoId: videoId,
          text: text,
        );
      }
      return true;
    } catch (e) {
      return false;
    }
  }

  Stream<List<CommentModel>> getComments(String videoId) {
    return _db.collection('videos').doc(videoId).collection('comments')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((s) => s.docs.map((d) => CommentModel.fromMap(d.data())).toList());
  }

  // ═══════════════════════════════════════════════════════════════════
  // 7. البحث (Search)
  // ═══════════════════════════════════════════════════════════════════

  Future<List<VideoModel>> searchVideos(String query) async {
    try {
      final q = query.toLowerCase().trim();
      if (q.isEmpty) return [];
      
      // نجيب آخر 100 فيديو ونفلترهن (لأن Firestore ما يدعم بحث نصي متقدم)
      final snap = await _db.collection('videos')
          .orderBy('createdAt', descending: true)
          .limit(100)
          .get();
          
      return snap.docs
          .map((d) => VideoModel.fromMap(d.data()))
          .where((v) => 
              v.caption.toLowerCase().contains(q) || 
              v.username.toLowerCase().contains(q))
          .toList();
    } catch (e) {
      return [];
    }
  }
}