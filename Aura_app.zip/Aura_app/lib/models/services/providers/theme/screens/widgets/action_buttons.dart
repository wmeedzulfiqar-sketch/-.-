// lib/widgets/action_buttons.dart
import 'package:flutter/material.dart';
import '../utils/formatters.dart';

class ActionButtons extends StatelessWidget {
  final int likes;
  final int comments;
  final int shares;
  final int saves;
  final bool isLiked;
  final bool isSaved;
  final VoidCallback onLike;
  final VoidCallback onComment;
  final VoidCallback onShare;
  final VoidCallback onSave;

  const ActionButtons({
    super.key,
    required this.likes,
    required this.comments,
    required this.shares,
    required this.saves,
    required this.isLiked,
    required this.isSaved,
    required this.onLike,
    required this.onComment,
    required this.onShare,
    required this.onSave,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _buildButton(
          icon: isLiked ? Icons.favorite : Icons.favorite_border,
          color: isLiked ? const Color(0xFFFE2C55) : Colors.white,
          label: Formatters.compactNumber(likes),
          onTap: onLike,
        ),
        const SizedBox(height: 20),
        _buildButton(
          icon: Icons.comment,
          label: Formatters.compactNumber(comments),
          onTap: onComment,
        ),
        const SizedBox(height: 20),
        _buildButton(
          icon: Icons.share,
          label: Formatters.compactNumber(shares),
          onTap: onShare,
        ),
        const SizedBox(height: 20),
        _buildButton(
          icon: isSaved ? Icons.bookmark : Icons.bookmark_border,
          color: isSaved ? const Color(0xFFFFD700) : Colors.white,
          label: Formatters.compactNumber(saves),
          onTap: onSave,
        ),
      ],
    );
  }

  Widget _buildButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    Color color = Colors.white,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.3),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: color, size: 32),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: const TextStyle(
              fontSize: 12,
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}