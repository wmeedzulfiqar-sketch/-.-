// lib/screens/inbox_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../services/chat_service.dart';
import '../services/auth_service.dart';
import '../providers/user_provider.dart';
import 'chat_screen.dart';

class InboxScreen extends StatelessWidget {
  const InboxScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = AuthService().currentUser?.uid ?? '';
    final chatService = ChatService();

    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      appBar: AppBar(
        title: const Text('الرسائل', style: TextStyle(color: Colors.white)),
        backgroundColor: const Color(0xFF0A0A0F),
        elevation: 0,
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: chatService.getChatsList(uid),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final chats = snapshot.data!;
          if (chats.isEmpty) {
            return const Center(
              child: Text('ما عندك رسائل حالياً', style: TextStyle(color: Colors.white54)),
            );
          }
          return ListView.builder(
            itemCount: chats.length,
            itemBuilder: (context, index) {
              final chat = chats[index];
              // نجيب ID الطرف الثاني
              final users = List<String>.from(chat['users'] ?? []);
              final otherId = users.firstWhere((id) => id != uid, orElse: () => '');
              
              return FutureBuilder(
                future: AuthService().getUser(otherId),
                builder: (context, userSnap) {
                  final otherUser = userSnap.data;
                  return ListTile(
                    leading: CircleAvatar(
                      backgroundImage: otherUser?.photoUrl != null ? NetworkImage(otherUser!.photoUrl!) : null,
                      child: otherUser?.photoUrl == null ? const Icon(Icons.person) : null,
                    ),
                    title: Text(otherUser?.username ?? 'مستخدم', style: const TextStyle(color: Colors.white)),
                    subtitle: Text(
                      chat['lastMessage'] ?? 'رسالة جديدة',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: Colors.white54),
                    ),
                    trailing: Text(
                      chat['lastAt'] != null ? DateFormat('HH:mm').format(DateTime.parse(chat['lastAt'])) : '',
                      style: const TextStyle(color: Colors.white54, fontSize: 12),
                    ),
                    onTap: () {
                      if (otherUser != null) {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ChatScreen(
                              otherId: otherUser.uid,
                              otherName: otherUser.username,
                              otherPhoto: otherUser.photoUrl ?? '',
                            ),
                          ),
                        );
                      }
                    },
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}