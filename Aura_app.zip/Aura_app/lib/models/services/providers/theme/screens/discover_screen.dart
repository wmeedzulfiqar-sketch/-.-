// lib/screens/discover_screen.dart
import 'package:flutter/material.dart';
import '../services/firestore_service.dart';
import '../models/video_model.dart';
import 'search_screen.dart';
import 'trends_screen.dart';
import '../widgets/video_player_widget.dart';

class DiscoverScreen extends StatefulWidget {
  const DiscoverScreen({super.key});

  @override
  State<DiscoverScreen> createState() => _DiscoverScreenState();
}

class _DiscoverScreenState extends State<DiscoverScreen> {
  final _firestore = FirestoreService();
  String _searchQuery = '';
  List<VideoModel> _searchResults = [];

  void _search(String query) async {
    if (query.trim().isEmpty) return;
    final results = await _firestore.searchVideos(query);
    setState(() {
      _searchQuery = query;
      _searchResults = results;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0A0A0F),
        title: TextField(
          onSubmitted: _search,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: 'ابحث عن فيديو، مستخدم...',
            hintStyle: const TextStyle(color: Colors.white54),
            filled: true,
            fillColor: Colors.white10,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
            prefixIcon: const Icon(Icons.search, color: Colors.white54),
          ),
        ),
      ),
      body: _searchQuery.isEmpty
          ? _buildTrendsAndSuggestions()
          : _buildSearchResults(),
    );
  }

  Widget _buildTrendsAndSuggestions() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('الترندات 🔥', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            TextButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TrendsScreen())),
              child: const Text('عرض الكل'),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: ['#بغداد', '#أكلات', '#رياضة', '#تقنية', '#فن', '#موسيقى']
              .map((tag) => ActionChip(
                    label: Text(tag, style: const TextStyle(color: Colors.white)),
                    backgroundColor: Colors.white12,
                    onPressed: () => _search(tag),
                  ))
              .toList(),
        ),
      ],
    );
  }

  Widget _buildSearchResults() {
    if (_searchResults.isEmpty) {
      return const Center(child: Text('ما في نتائج', style: TextStyle(color: Colors.white54)));
    }
    return GridView.builder(
      padding: const EdgeInsets.all(2),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3, crossAxisSpacing: 2, mainAxisSpacing: 2, childAspectRatio: 3 / 4,
      ),
      itemCount: _searchResults.length,
      itemBuilder: (context, index) {
        final video = _searchResults[index];
        return GestureDetector(
          onTap: () => Navigator.push(context, MaterialPageRoute(
            builder: (_) => Scaffold(body: VideoPlayerWidget(video: video), backgroundColor: Colors.black),
          )),
          child: Container(
            color: Colors.white12,
            child: const Icon(Icons.play_arrow, color: Colors.white54),
          ),
        );
      },
    );
  }
}