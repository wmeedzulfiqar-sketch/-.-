// lib/screens/saved_videos_screen.dart
import 'package:flutter/material.dart';
import '../services/firestore_service.dart';
import '../services/auth_service.dart';
import '../models/video_model.dart';
import '../widgets/video_player_widget.dart';

class SavedVideosScreen extends StatelessWidget {
  const SavedVideosScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final firestore = FirestoreService();
    final uid = AuthService().currentUser?.uid ?? '';

    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      appBar: AppBar(title: const Text('المحفوظات', style: TextStyle(color: Colors.white)), backgroundColor: const Color(0xFF0A0A0F)),
      body: StreamBuilder<List<VideoModel>>(
        stream: firestore.getSavedVideos(uid),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final videos = snapshot.data!;
          if (videos.isEmpty) return const Center(child: Text('ما في محفوظات', style: TextStyle(color: Colors.white54)));

          return GridView.builder(
            padding: const EdgeInsets.all(2),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 2, mainAxisSpacing: 2, childAspectRatio: 3 / 4),
            itemCount: videos.length,
            itemBuilder: (context, i) {
              final v = videos[i];
              return GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => Scaffold(body: VideoPlayerWidget(video: v)))),
                child: Container(color: Colors.white10, child: const Icon(Icons.play_arrow, color: Colors.white54)),
              );
            },
          );
        },
      ),
    );
  }
}