// lib/utils/validators.dart
// دوال للتحقق من صحة المدخلات (Validation)

class Validators {
  // ─── التحقق من الإيميل ───
  static String? email(String? value) {
    if (value == null || value.isEmpty) {
      return 'الإيميل مطلوب';
    }
    final regex = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
    if (!regex.hasMatch(value)) {
      return 'صيغة الإيميل غير صحيحة';
    }
    return null;
  }

  // ─── التحقق من كلمة المرور ───
  static String? password(String? value) {
    if (value == null || value.isEmpty) {
      return 'كلمة المرور مطلوبة';
    }
    if (value.length < 6) {
      return 'كلمة المرور يجب أن تكون 6 أحرف على الأقل';
    }
    return null;
  }

  // ─── التحقق من اسم المستخدم ───
  static String? username(String? value) {
    if (value == null || value.isEmpty) {
      return 'اسم المستخدم مطلوب';
    }
    if (value.length < 3) {
      return 'اسم المستخدم يجب أن يكون 3 أحرف على الأقل';
    }
    if (value.length > 20) {
      return 'اسم المستخدم يجب أن يكون أقل من 20 حرف';
    }
    final regex = RegExp(r'^[a-zA-Z0-9_]+$');
    if (!regex.hasMatch(value)) {
      return 'يسمح فقط بالحروف الإنجليزية والأرقام والشرطة السفلية (_)';
    }
    return null;
  }

  // ─── التحقق من النص العادي ───
  static String? text(String? value, {int? maxLength}) {
    if (value == null || value.trim().isEmpty) {
      return 'هذا الحقل مطلوب';
    }
    if (maxLength != null && value.length > maxLength) {
      return 'النص طويل جداً (الحد الأقصى $maxLength حرف)';
    }
    return null;
  }
}