// lib/screens/search_screen.dart
import 'package:flutter/material.dart';
import '../services/firestore_service.dart';
import '../models/video_model.dart';
import '../widgets/video_player_widget.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _firestore = FirestoreService();
  final _controller = TextEditingController();
  List<VideoModel> _results = [];
  bool _loading = false;

  Future<void> _search(String query) async {
    if (query.trim().isEmpty) return;
    setState(() => _loading = true);
    final res = await _firestore.searchVideos(query);
    if (mounted) setState(() { _results = res; _loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0A0A0F),
        title: TextField(
          controller: _controller,
          autofocus: true,
          style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(hintText: 'ابحث...', hintStyle: TextStyle(color: Colors.white54), border: InputBorder.none),
          onSubmitted: _search,
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _results.isEmpty
              ? const Center(child: Text('اكتب شي للبحث', style: TextStyle(color: Colors.white54)))
              : GridView.builder(
                  padding: const EdgeInsets.all(2),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 2, mainAxisSpacing: 2, childAspectRatio: 3 / 4),
                  itemCount: _results.length,
                  itemBuilder: (context, i) {
                    final v = _results[i];
                    return GestureDetector(
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => Scaffold(body: VideoPlayerWidget(video: v)))),
                      child: Container(color: Colors.white10, child: const Icon(Icons.play_arrow, color: Colors.white54)),
                    );
                  },
                ),
    );
  }
}