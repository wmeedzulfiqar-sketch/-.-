// lib/widgets/notification_tile.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/notification_model.dart';
import 'user_avatar.dart';

class NotificationTile extends StatelessWidget {
  final AppNotification notification;
  final VoidCallback onTap;

  const NotificationTile({
    super.key,
    required this.notification,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      leading: Stack(
        children: [
          UserAvatar(
            photoUrl: notification.actorPhoto,
            username: notification.actorName,
            radius: 22,
          ),
          Positioned(
            right: -2,
            bottom: -2,
            child: Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: _getIconColor(notification.type),
                shape: BoxShape.circle,
                border: Border.all(color: const Color(0xFF0A0A0F), width: 2),
              ),
              child: Icon(
                _getIcon(notification.type),
                size: 12,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
      title: Text(
        _getTitle(),
        style: TextStyle(
          color: Colors.white,
          fontWeight: notification.read ? FontWeight.normal : FontWeight.bold,
        ),
      ),
      subtitle: Text(
        DateFormat('hh:mm a · dd/MM').format(notification.createdAt),
        style: const TextStyle(color: Colors.white54, fontSize: 12),
      ),
      trailing: notification.videoThumb != null
          ? ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: Image.network(
                notification.videoThumb!,
                width: 40, height: 50, fit: BoxFit.cover,
              ),
            )
          : null,
      tileColor: notification.read ? null : Colors.white.withOpacity(0.05),
    );
  }

  String _getTitle() {
    switch (notification.type) {
      case 'follow':
        return '${notification.actorName} بدأ متابعتك';
      case 'like':
        return '${notification.actorName} أعجب بفيديوك';
      case 'comment':
        return '${notification.actorName} علق: ${notification.text ?? ""}';
      default:
        return 'إشعار جديد';
    }
  }

  IconData _getIcon(String type) {
    switch (type) {
      case 'follow': return Icons.person_add;
      case 'like': return Icons.favorite;
      case 'comment': return Icons.comment;
      default: return Icons.notifications;
    }
  }

  Color _getIconColor(String type) {
    switch (type) {
      case 'follow': return Colors.blue;
      case 'like': return Colors.pink;
      case 'comment': return Colors.orange;
      default: return Colors.purple;
    }
  }
}