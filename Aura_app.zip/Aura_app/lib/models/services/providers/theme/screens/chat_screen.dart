// lib/screens/chat_screen.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:intl/intl.dart';
import '../models/message_model.dart';
import '../services/chat_service.dart';
import '../services/storage_service.dart';
import '../services/auth_service.dart';
import 'call_screen.dart';

class ChatScreen extends StatefulWidget {
  final String otherId;
  final String otherName;
  final String otherPhoto;
  const ChatScreen({super.key, required this.otherId, required this.otherName, required this.otherPhoto});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _chatService = ChatService();
  final _storageService = StorageService();
  final _auth = AuthService();
  final _ctrl = TextEditingController();
  
  final _recorder = FlutterSoundRecorder();
  bool _isRecording = false;
  DateTime? _recordingStart;
  bool _isUploadingVoice = false;

  String get _myId => _auth.currentUser?.uid ?? '';

  @override
  void initState() {
    super.initState();
    _initRecorder();
  }

  Future<void> _initRecorder() async {
    await _recorder.openRecorder();
  }

  @override
  void dispose() {
    _recorder.closeRecorder();
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _sendText() async {
    final text = _ctrl.text.trim();
    if (text.isEmpty) return;
    
    _ctrl.clear();
    final success = await _chatService.sendText(_myId, widget.otherId, text);
    if (!mounted) return;
    if (!success) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('فشل إرسال الرسالة، تحقق من الإنترنت')));
    }
  }

  Future<void> _startRecording() async {
    final status = await Permission.microphone.request();
    if (!status.isGranted) return;

    final dir = await getTemporaryDirectory();
    final path = '${dir.path}/voice_${DateTime.now().millisecondsSinceEpoch}.aac';
    
    await _recorder.startRecorder(toFile: path, codec: Codec.aacADTS);
    setState(() {
      _isRecording = true;
      _recordingStart = DateTime.now();
    });
  }

  Future<void> _stopAndSendRecording() async {
    final path = await _recorder.stopRecorder();
    setState(() => _isRecording = false);
    
    if (path == null || _recordingStart == null) return;
    final duration = DateTime.now().difference(_recordingStart!).inSeconds;
    
    if (duration < 1) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('التسجيل قصير جداً')));
      return;
    }

    setState(() => _isUploadingVoice = true);

    // رفع الصوت
    final url = await _storageService.uploadVoice(file: File(path), userId: _myId);
    if (!mounted) return;

    if (url != null) {
      await _chatService.sendVoice(_myId, widget.otherId, url, duration);
    } else {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('فشل رفع البصمة الصوتية')));
    }

    if (mounted) setState(() => _isUploadingVoice = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0A0A0F),
        title: Row(
          children: [
            CircleAvatar(
              backgroundImage: widget.otherPhoto.isNotEmpty ? NetworkImage(widget.otherPhoto) : null,
              child: widget.otherPhoto.isEmpty ? const Icon(Icons.person) : null,
            ),
            const SizedBox(width: 12),
            Text(widget.otherName, style: const TextStyle(color: Colors.white)),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.call, color: Colors.white),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CallScreen(otherId: widget.otherId, otherName: widget.otherName, isVideo: false))),
          ),
          IconButton(
            icon: const Icon(Icons.videocam, color: Colors.white),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CallScreen(otherId: widget.otherId, otherName: widget.otherName, isVideo: true))),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<List<MessageModel>>(
              stream: _chatService.getMessages(_myId, widget.otherId),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
                final messages = snapshot.data!;
                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: messages.length,
                  itemBuilder: (context, i) {
                    final m = messages[i];
                    final isMe = m.senderId == _myId;
                    return _buildBubble(m, isMe);
                  },
                );
              },
            ),
          ),
          if (_isRecording)
            Container(
              padding: const EdgeInsets.all(12),
              color: Colors.red.withOpacity(0.2),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.mic, color: Colors.red),
                  SizedBox(width: 8),
                  Text('جاري التسجيل...', style: TextStyle(color: Colors.red)),
                ],
              ),
            ),
          if (_isUploadingVoice)
            const Padding(
              padding: EdgeInsets.all(8.0),
              child: LinearProgressIndicator(),
            ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _ctrl,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: 'اكتب رسالة...',
                      hintStyle: const TextStyle(color: Colors.white54),
                      filled: true,
                      fillColor: const Color(0xFF1A1A2E),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    ),
                    onSubmitted: (_) => _sendText(),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: Icon(_isRecording ? Icons.stop : Icons.mic, color: _isRecording ? Colors.red : Colors.white),
                  onPressed: _isRecording ? _stopAndSendRecording : _startRecording,
                ),
                IconButton(
                  icon: const Icon(Icons.send, color: Colors.white),
                  onPressed: _sendText,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBubble(MessageModel m, bool isMe) {
    return Align(
      alignment: isMe ? Alignment.centerLeft : Alignment.centerRight,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.all(12),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
        decoration: BoxDecoration(
          color: isMe ? Theme.of(context).colorScheme.primary : const Color(0xFF1A1A2E),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (m.type == 'voice')
              Row(
                children: [
                  const Icon(Icons.play_circle, color: Colors.white, size: 24),
                  const SizedBox(width: 8),
                  Text('${m.duration} ثانية', style: const TextStyle(color: Colors.white)),
                ],
              )
            else
              Text(m.content, style: const TextStyle(color: Colors.white)),
            const SizedBox(height: 4),
            Text(DateFormat('hh:mm a').format(m.createdAt), style: const TextStyle(fontSize: 10, color: Colors.white54)),
          ],
        ),
      ),
    );
  }
}