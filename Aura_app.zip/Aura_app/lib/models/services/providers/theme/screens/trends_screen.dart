// lib/screens/trends_screen.dart
import 'package:flutter/material.dart';
import '../services/trends_service.dart';

class TrendsScreen extends StatelessWidget {
  const TrendsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final service = TrendsService();
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      appBar: AppBar(title: const Text('الترندات', style: TextStyle(color: Colors.white)), backgroundColor: const Color(0xFF0A0A0F)),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: service.getTrends(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final trends = snapshot.data!;
          if (trends.isEmpty) return const Center(child: Text('ما في ترندات حالياً', style: TextStyle(color: Colors.white54)));

          return ListView.builder(
            itemCount: trends.length,
            itemBuilder: (context, i) {
              final t = trends[i];
              return ListTile(
                leading: CircleAvatar(
                  backgroundColor: Theme.of(context).colorScheme.primary.withOpacity(0.2),
                  child: Text('${i + 1}', style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.bold)),
                ),
                title: Text('#${t['tag']}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                subtitle: Text('${t['count']} فيديو', style: const TextStyle(color: Colors.white54)),
                trailing: const Icon(Icons.trending_up, color: Colors.white54),
                onTap: () {},
              );
            },
          );
        },
      ),
    );
  }
}