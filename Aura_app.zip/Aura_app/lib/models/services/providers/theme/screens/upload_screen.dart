// lib/screens/upload_screen.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';
import '../models/video_model.dart';
import '../services/storage_service.dart';
import '../services/firestore_service.dart';
import '../services/auth_service.dart';

class UploadScreen extends StatefulWidget {
  const UploadScreen({super.key});

  @override
  State<UploadScreen> createState() => _UploadScreenState();
}

class _UploadScreenState extends State<UploadScreen> {
  final _captionController = TextEditingController();
  final _storage = StorageService();
  final _firestore = FirestoreService();
  final _auth = AuthService();
  final _uuid = const Uuid();
  
  File? _videoFile;
  bool _isUploading = false;
  double _uploadProgress = 0.0;
  String _statusMessage = '';

  Future<void> _pickVideo() async {
    final picker = ImagePicker();
    final picked = await picker.pickVideo(source: ImageSource.gallery);
    if (picked != null) {
      setState(() => _videoFile = File(picked.path));
    }
  }

  Future<void> _upload() async {
    if (_videoFile == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اختر فيديو أولاً')));
      return;
    }

    final uid = _auth.currentUser?.uid;
    if (uid == null) return;

    setState(() { _isUploading = true; _statusMessage = 'جاري الرفع...'; });

    // 1. جلب بيانات المستخدم
    final user = await _auth.getUser(uid);
    if (!mounted) return;

    // 2. رفع الفيديو
    final videoUrl = await _storage.uploadVideo(
      file: _videoFile!,
      userId: uid,
      onProgress: (progress) {
        if (mounted) setState(() { _uploadProgress = progress; });
      },
    );

    if (!mounted) return;

    if (videoUrl == null) {
      setState(() { _isUploading = false; _statusMessage = 'فشل الرفع' });
      return;
    }

    // 3. حفظ البيانات في Firestore
    setState(() => _statusMessage = 'جاري الحفظ...');
    final video = VideoModel(
      id: _uuid.v4(),
      userId: uid,
      username: user?.username ?? 'user',
      videoUrl: videoUrl,
      caption: _captionController.text.trim(),
      createdAt: DateTime.now(),
    );

    final success = await _firestore.addVideo(video);
    if (!mounted) return;

    if (success) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم رفع الفيديو بنجاح')));
    } else {
      setState(() { _isUploading = false; _statusMessage = 'فشل الحفظ في قاعدة البيانات' });
    }
  }

  @override
  void dispose() {
    _captionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      appBar: AppBar(
        title: const Text('رفع فيديو', style: TextStyle(color: Colors.white)),
        backgroundColor: const Color(0xFF0A0A0F),
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            GestureDetector(
              onTap: _isUploading ? null : _pickVideo,
              child: Container(
                height: 200,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: const Color(0xFF1A1A2E),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white12, style: BorderStyle.solid),
                ),
                child: Center(
                  child: _videoFile == null
                      ? const Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.video_library, size: 60, color: Colors.white54),
                            SizedBox(height: 12),
                            Text('اضغط لاختيار فيديو', style: TextStyle(color: Colors.white54)),
                          ],
                        )
                      : const Icon(Icons.check_circle, size: 60, color: Colors.green),
                ),
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _captionController,
              maxLines: 3,
              maxLength: 2200,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: 'الوصف',
                labelStyle: const TextStyle(color: Colors.white54),
                hintText: 'اكتب شي عن الفيديو...',
                hintStyle: const TextStyle(color: Colors.white24),
                filled: true,
                fillColor: const Color(0xFF1A1A2E),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              ),
            ),
            const Spacer(),
            if (_isUploading) ...[
              LinearProgressIndicator(value: _uploadProgress, backgroundColor: Colors.white12, color: Theme.of(context).colorScheme.primary),
              const SizedBox(height: 8),
              Text(_statusMessage, style: const TextStyle(color: Colors.white54)),
              const SizedBox(height: 16),
            ],
            ElevatedButton(
              onPressed: _isUploading ? null : _upload,
              style: ElevatedButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.primary,
                minimumSize: const Size.fromHeight(56),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text('رفع', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }
}