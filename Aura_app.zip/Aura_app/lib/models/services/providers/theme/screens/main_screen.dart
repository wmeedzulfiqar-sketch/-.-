// lib/screens/main_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../widgets/aura_bottom_nav.dart';
import '../providers/user_provider.dart';
import 'home_screen.dart';
import 'discover_screen.dart';
import 'upload_screen.dart';
import 'inbox_screen.dart';
import 'profile_screen.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    final userProvider = Provider.of<UserProvider>(context);
    final userId = userProvider.user?.uid ?? '';

    // الشاشات اللي راح تتبدل
    final List<Widget> _screens = [
      const HomeScreen(),
      const DiscoverScreen(),
      const SizedBox(), // زر الرفع يفتح شاشة منفصلة
      const InboxScreen(),
      ProfileScreen(userId: userId),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      extendBody: true, // عشان الشريط يكون شفاف
      body: _screens[_currentIndex],
      bottomNavigationBar: AuraBottomNav(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() => _currentIndex = index);
        },
        onUploadTap: () {
          // فتح شاشة الرفع
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const UploadScreen()),
          );
        },
      ),
    );
  }
}