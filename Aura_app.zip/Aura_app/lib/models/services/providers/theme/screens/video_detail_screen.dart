// lib/screens/video_detail_screen.dart
import 'package:flutter/material.dart';
import '../models/video_model.dart';
import '../widgets/video_player_widget.dart';

class VideoDetailScreen extends StatelessWidget {
  final VideoModel video;
  const VideoDetailScreen({super.key, required this.video});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: VideoPlayerWidget(video: video),
      ),
    );
  }
}