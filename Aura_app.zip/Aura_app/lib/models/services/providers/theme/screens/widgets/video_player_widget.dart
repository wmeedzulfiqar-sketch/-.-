// lib/widgets/video_player_widget.dart
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../models/video_model.dart';
import '../services/firestore_service.dart';
import '../services/auth_service.dart';
import '../utils/formatters.dart';
import '../screens/comments_screen.dart';
import 'share_sheet.dart';

class VideoPlayerWidget extends StatefulWidget {
  final VideoModel video;
  const VideoPlayerWidget({super.key, required this.video});

  @override
  State<VideoPlayerWidget> createState() => _VideoPlayerWidgetState();
}

class _VideoPlayerWidgetState extends State<VideoPlayerWidget> {
  late VideoPlayerController _controller;
  final _firestore = FirestoreService();
  final _auth = AuthService();
  
  bool _paused = false;
  bool _viewCounted = false;

  @override
  void initState() {
    super.initState();
    
    // تهيئة الفيديو
    _controller = VideoPlayerController.networkUrl(Uri.parse(widget.video.videoUrl))
      ..initialize().then((_) {
        _controller.setLooping(true);
        _controller.play();
        if (mounted) setState(() {});
      });

    // عد المشاهدة
    Future.delayed(const Duration(seconds: 2), () {
      if (!_viewCounted && mounted) {
        _firestore.incrementView(widget.video.id);
        _viewCounted = true;
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _togglePlay() {
    setState(() {
      _paused = !_paused;
      _paused ? _controller.pause() : _controller.play();
    });
  }

  void _openShareSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => ShareSheet(videoId: widget.video.id, caption: widget.video.caption),
    );
  }

  @override
  Widget build(BuildContext context) {
    final uid = _auth.currentUser?.uid ?? '';

    return GestureDetector(
      onTap: _togglePlay,
      child: Stack(
        fit: StackFit.expand,
        children: [
          // 1. الفيديو أو الصورة المصغرة
          if (_controller.value.isInitialized)
            FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _controller.value.size.width,
                height: _controller.value.size.height,
                child: VideoPlayer(_controller),
              ),
            )
          else
            Center(
              child: CachedNetworkImage(
                imageUrl: widget.video.thumbnailUrl ?? '',
                fit: BoxFit.cover,
                placeholder: (_, __) => const Center(child: CircularProgressIndicator()),
                errorWidget: (_, __, ___) => const Icon(Icons.error, color: Colors.white),
              ),
            ),

          // 2. أيقونة التشغيل
          if (_paused)
            const Center(child: Icon(Icons.play_arrow, size: 80, color: Colors.white70)),

          // 3. تدرج لوني
          Positioned(
            bottom: 0, left: 0, right: 0, height: 250,
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [Colors.black87, Colors.transparent],
                ),
              ),
            ),
          ),

          // 4. معلومات الفيديو
          Positioned(
            bottom: 100, right: 16, left: 80,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('@${widget.video.username}',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white)),
                const SizedBox(height: 8),
                Text(widget.video.caption,
                    maxLines: 2, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 14, color: Colors.white)),
              ],
            ),
          ),

          // 5. أزرار التفاعل
          Positioned(
            bottom: 100, right: 12,
            child: Column(
              children: [
                StreamBuilder<bool>(
                  stream: _firestore.isLiked(widget.video.id, uid),
                  builder: (context, snap) {
                    final liked = snap.data ?? false;
                    return _actionBtn(
                      icon: liked ? Icons.favorite : Icons.favorite_border,
                      color: liked ? const Color(0xFFFE2C55) : Colors.white,
                      label: Formatters.compactNumber(widget.video.likes + (liked ? 1 : 0)),
                      onTap: () => _firestore.toggleLike(widget.video.id, uid),
                    );
                  },
                ),
                const SizedBox(height: 20),
                _actionBtn(
                  icon: Icons.comment,
                  label: Formatters.compactNumber(widget.video.comments),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CommentsScreen(videoId: widget.video.id))),
                ),
                const SizedBox(height: 20),
                _actionBtn(
                  icon: Icons.share,
                  label: Formatters.compactNumber(widget.video.shares),
                  onTap: () {
                    _firestore.incrementShare(widget.video.id);
                    _openShareSheet();
                  },
                ),
                const SizedBox(height: 20),
                StreamBuilder<bool>(
                  stream: _firestore.isSaved(widget.video.id, uid),
                  builder: (context, snap) {
                    final saved = snap.data ?? false;
                    return _actionBtn(
                      icon: saved ? Icons.bookmark : Icons.bookmark_border,
                      color: saved ? const Color(0xFFFFD700) : Colors.white,
                      label: Formatters.compactNumber(widget.video.saves + (saved ? 1 : 0)),
                      onTap: () => _firestore.toggleSave(widget.video.id, uid),
                    );
                  },
                ),
              ],
            ),
          ),

          // 6. زر المتابعة
          Positioned(
            bottom: 60, right: 16,
            child: StreamBuilder<bool>(
              stream: _firestore.isFollowing(uid, widget.video.userId),
              builder: (context, snap) {
                if (widget.video.userId == uid) return const SizedBox();
                final following = snap.data ?? false;
                return GestureDetector(
                  onTap: () => _firestore.toggleFollow(uid, widget.video.userId),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: following ? Colors.white24 : const Color(0xFFFE2C55),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      following ? 'إلغاء المتابعة' : 'متابعة',
                      style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _actionBtn({required IconData icon, required String label, required VoidCallback onTap, Color color = Colors.white}) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Icon(icon, color: color, size: 36),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(fontSize: 12, color: Colors.white, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}