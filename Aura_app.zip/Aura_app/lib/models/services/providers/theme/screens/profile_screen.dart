// lib/screens/profile_screen.dart
import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';
import '../models/user_model.dart';
import '../models/video_model.dart';
import '../utils/formatters.dart';
import 'settings_screen.dart';

class ProfileScreen extends StatefulWidget {
  final String userId;
  const ProfileScreen({super.key, required this.userId});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _auth = AuthService();
  final _firestore = FirestoreService();
  UserModel? _user;

  @override
  void initState() {
    super.initState();
    _loadUser();
  }

  Future<void> _loadUser() async {
    final u = await _auth.getUser(widget.userId);
    if (mounted) setState(() => _user = u);
  }

  @override
  Widget build(BuildContext context) {
    if (_user == null) return const Scaffold(backgroundColor: Color(0xFF0A0A0F), body: Center(child: CircularProgressIndicator()));

    final isMe = widget.userId == _auth.currentUser?.uid;

    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0A0A0F),
        elevation: 0,
        title: Text(_user!.username, style: const TextStyle(color: Colors.white)),
        actions: [
          if (isMe)
            IconButton(
              icon: const Icon(Icons.settings, color: Colors.white),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen())),
            ),
        ],
      ),
      body: Column(
        children: [
          // معلومات الحساب
          Padding(
            padding: const EdgeInsets.all(24),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                CircleAvatar(
                  radius: 40,
                  backgroundColor: Colors.white12,
                  backgroundImage: _user!.photoUrl != null ? NetworkImage(_user!.photoUrl!) : null,
                  child: _user!.photoUrl == null ? const Icon(Icons.person, color: Colors.white54, size: 40) : null,
                ),
                _stat('${_user!.following}', 'يتابع'),
                _stat('${_user!.followers}', 'متابع'),
              ],
            ),
          ),
          const Divider(color: Colors.white12),
          // شبكة الفيديوهات
          Expanded(
            child: FutureBuilder<List<VideoModel>>(
              future: _firestore.searchVideos(''), // كود مؤقت لجلب الفيديوهات (يفضل تعديله لدالة تجيب فيديوهات المستخدم فقط)
              builder: (context, snap) {
                if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                final videos = snap.data!.where((v) => v.userId == widget.userId).toList();
                if (videos.isEmpty) return const Center(child: Text('ما في فيديوهات', style: TextStyle(color: Colors.white54)));
                return GridView.builder(
                  padding: const EdgeInsets.all(2),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3, crossAxisSpacing: 2, mainAxisSpacing: 2, childAspectRatio: 3 / 4,
                  ),
                  itemCount: videos.length,
                  itemBuilder: (context, index) {
                    final v = videos[index];
                    return Container(
                      color: Colors.white10,
                      child: Stack(
                        children: [
                          if (v.thumbnailUrl != null) Image.network(v.thumbnailUrl!, fit: BoxFit.cover),
                          Positioned(
                            bottom: 4, right: 4,
                            child: Row(children: [
                              const Icon(Icons.play_arrow, size: 14, color: Colors.white),
                              Text(Formatters.compactNumber(v.views), style: const TextStyle(color: Colors.white, fontSize: 12)),
                            ]),
                          ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _stat(String value, String label) {
    return Column(
      children: [
        Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
        Text(label, style: const TextStyle(fontSize: 12, color: Colors.white54)),
      ],
    );
  }
}