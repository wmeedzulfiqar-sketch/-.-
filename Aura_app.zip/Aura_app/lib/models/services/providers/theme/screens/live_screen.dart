// lib/screens/live_screen.dart
import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../utils/constants.dart';

class LiveScreen extends StatefulWidget {
  const LiveScreen({super.key});

  @override
  State<LiveScreen> createState() => _LiveScreenState();
}

class _LiveScreenState extends State<LiveScreen> {
  final _auth = AuthService();
  int _followers = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final u = await _auth.getUser(_auth.currentUser?.uid ?? '');
    if (mounted) setState(() { _followers = u?.followers ?? 0; _loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(backgroundColor: Color(0xFF0A0A0F), body: Center(child: CircularProgressIndicator()));

    final canGoLive = _followers >= AppConstants.minFollowersForLive;

    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      appBar: AppBar(title: const Text('البث المباشر', style: TextStyle(color: Colors.white)), backgroundColor: const Color(0xFF0A0A0F)),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(canGoLive ? Icons.videocam : Icons.lock, size: 100, color: canGoLive ? Theme.of(context).colorScheme.primary : Colors.white38),
              const SizedBox(height: 24),
              Text(canGoLive ? 'جاهز للبث!' : 'تحتاج ${AppConstants.minFollowersForLive} متابع', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white)),
              const SizedBox(height: 12),
              Text('عندك $_followers / ${AppConstants.minFollowersForLive} متابع', style: const TextStyle(color: Colors.white54)),
              const SizedBox(height: 8),
              LinearProgressIndicator(value: (_followers / AppConstants.minFollowersForLive).clamp(0.0, 1.0), backgroundColor: Colors.white12),
              const SizedBox(height: 32),
              ElevatedButton(
                onPressed: canGoLive ? () {} : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: canGoLive ? Theme.of(context).colorScheme.primary : Colors.grey[800],
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
                ),
                child: Text(canGoLive ? 'ابدأ البث' : 'احصل على متابعين', style: const TextStyle(color: Colors.white)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}