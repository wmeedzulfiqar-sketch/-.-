// lib/screens/settings_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/settings_service.dart';
import '../theme/app_theme.dart';
import '../providers/theme_provider.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  Map<String, dynamic> _values = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final v = await SettingsService.loadAll();
    if (mounted) setState(() { _values = v; _loading = false; });
  }

  Future<void> _set(String key, dynamic value) async {
    setState(() => _values[key] = value);
    await SettingsService.set(key, value);
    
    // إذا كان تغيير اللون أو الوضع الليلي، نحدث الـ ThemeProvider فوراً
    if (key == 'dark_mode' && mounted) {
      context.read<ThemeProvider>().toggleDark();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(backgroundColor: Color(0xFF0A0A0F), body: Center(child: CircularProgressIndicator()));

    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      appBar: AppBar(title: const Text('الإعدادات'), backgroundColor: const Color(0xFF0A0A0F)),
      body: ListView.builder(
        itemCount: SettingsService.features.length,
        itemBuilder: (context, index) {
          final f = SettingsService.features[index];
          final key = f['key'] as String;
          final type = f['type'] as String;
          final name = f['name'] as String;
          final desc = f['desc'] as String? ?? '';
          final value = _values[key];

          if (type == 'bool') {
            return SwitchListTile(
              title: Text(name, style: const TextStyle(color: Colors.white)),
              subtitle: Text(desc, style: const TextStyle(color: Colors.white54)),
              value: value == true,
              activeColor: Theme.of(context).colorScheme.primary,
              onChanged: (v) => _set(key, v),
            );
          } else if (type == 'color') {
            final idx = value as int? ?? 0;
            return ListTile(
              title: Text(name, style: const TextStyle(color: Colors.white)),
              subtitle: Text(AppTheme.colorNames[idx], style: const TextStyle(color: Colors.white54)),
              trailing: Container(width: 24, height: 24, decoration: BoxDecoration(color: AppTheme.primaryColors[idx], shape: BoxShape.circle)),
              onTap: () async {
                final picked = await showDialog<int>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    backgroundColor: const Color(0xFF1A1A2E),
                    title: const Text('اختر لون'),
                    content: Wrap(
                      spacing: 12, runSpacing: 12,
                      children: List.generate(AppTheme.primaryColors.length, (i) {
                        return GestureDetector(
                          onTap: () => Navigator.pop(ctx, i),
                          child: Container(
                            width: 40, height: 40,
                            decoration: BoxDecoration(
                              color: AppTheme.primaryColors[i], shape: BoxShape.circle,
                              border: i == idx ? Border.all(color: Colors.white, width: 3) : null,
                            ),
                          ),
                        );
                      }),
                    ),
                  ),
                );
                if (picked != null) {
                  await _set(key, picked);
                  if (mounted) context.read<ThemeProvider>().setPrimaryColor(picked);
                }
              },
            );
          } else if (type == 'action') {
            return ListTile(
              title: Text(name, style: const TextStyle(color: Colors.white)),
              subtitle: Text(desc, style: const TextStyle(color: Colors.white54)),
              trailing: const Icon(Icons.chevron_left, color: Colors.white54),
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$name — قريباً')));
              },
            );
          }
          return const SizedBox();
        },
      ),
    );
  }
}