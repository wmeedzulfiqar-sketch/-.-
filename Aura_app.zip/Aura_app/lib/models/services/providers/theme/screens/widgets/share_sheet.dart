// lib/widgets/share_sheet.dart
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../utils/constants.dart';

class ShareSheet extends StatelessWidget {
  final String videoId;
  final String caption;

  const ShareSheet({
    super.key,
    required this.videoId,
    required this.caption,
  });

  void _shareToTelegram(BuildContext context, String url) async {
    final text = Uri.encodeComponent('شوف هذا الفيديو على Aura:\n$caption\n\n$url');
    final tgUrl = Uri.parse('https://t.me/share/url?url=$url&text=$text');
    if (await canLaunchUrl(tgUrl)) {
      await launchUrl(tgUrl, mode: LaunchMode.externalApplication);
    }
    if (context.mounted) Navigator.pop(context);
  }

  void _shareToFacebook(BuildContext context, String url) async {
    final fbUrl = Uri.parse('https://www.facebook.com/sharer/sharer.php?u=$url');
    if (await canLaunchUrl(fbUrl)) {
      await launchUrl(fbUrl, mode: LaunchMode.externalApplication);
    }
    if (context.mounted) Navigator.pop(context);
  }

  void _shareToWhatsApp(BuildContext context, String url) async {
    final text = Uri.encodeComponent('شوف هذا الفيديو على Aura:\n$caption\n\n$url');
    final waUrl = Uri.parse('https://wa.me/?text=$text');
    if (await canLaunchUrl(waUrl)) {
      await launchUrl(waUrl, mode: LaunchMode.externalApplication);
    }
    if (context.mounted) Navigator.pop(context);
  }

  void _shareNative(BuildContext context, String url) {
    Share.share('شوف هذا الفيديو على Aura:\n$caption\n\n$url');
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final url = '${AppConstants.shareBaseUrl}$videoId';

    return Container(
      padding: const EdgeInsets.all(24),
      decoration: const BoxDecoration(
        color: Color(0xFF1A1A2E),
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 40, height: 4,
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2)),
          ),
          const SizedBox(height: 20),
          const Text('شارك الفيديو', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _iconBtn(Icons.telegram, const Color(0xFF0088CC), 'تليكرام', () => _shareToTelegram(context, url)),
              _iconBtn(Icons.facebook, const Color(0xFF1877F2), 'فيسبوك', () => _shareToFacebook(context, url)),
              _iconBtn(Icons.chat, const Color(0xFF25D366), 'واتساب', () => _shareToWhatsApp(context, url)),
              _iconBtn(Icons.more_horiz, const Color(0xFF667EEA), 'المزيد', () => _shareNative(context, url)),
            ],
          ),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _iconBtn(IconData icon, Color color, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 56, height: 56,
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(icon, color: color, size: 28),
          ),
          const SizedBox(height: 8),
          Text(label, style: const TextStyle(fontSize: 12, color: Colors.white)),
        ],
      ),
    );
  }
}