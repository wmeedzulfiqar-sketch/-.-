// lib/screens/comments_screen.dart
import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';
import 'package:intl/intl.dart';
import '../models/comment_model.dart';
import '../services/firestore_service.dart';
import '../services/auth_service.dart';

class CommentsScreen extends StatefulWidget {
  final String videoId;
  const CommentsScreen({super.key, required this.videoId});

  @override
  State<CommentsScreen> createState() => _CommentsScreenState();
}

class _CommentsScreenState extends State<CommentsScreen> {
  final _firestore = FirestoreService();
  final _auth = AuthService();
  final _controller = TextEditingController();
  final _localAuth = LocalAuthentication();
  bool _isSending = false;

  // التحقق من البصمة (اختياري — نستخدمه قبل إرسال التعليق)
  Future<bool> _authBiometric() async {
    try {
      final canCheck = await _localAuth.canCheckBiometrics;
      if (!canCheck) return true; // إذا الجهاز ما يدعم البصمة، نكمل عادي
      
      return await _localAuth.authenticate(
        localizedReason: 'تأكيد التعليق ببصمة الإصبع',
        options: const AuthenticationOptions(biometricOnly: true),
      );
    } catch (e) {
      return false;
    }
  }

  Future<void> _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;

    setState(() => _isSending = true);

    // 1. طلب البصمة
    final authOk = await _authBiometric();
    if (!mounted) return;
    if (!authOk) {
      setState(() => _isSending = false);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تحتاج بصمة لإرسال التعليق')));
      return;
    }

    // 2. إرسال التعليق
    final uid = _auth.currentUser?.uid ?? '';
    final user = await _auth.getUser(uid);
    if (!mounted) return;

    final success = await _firestore.addComment(
      videoId: widget.videoId,
      userId: uid,
      username: user?.username ?? 'user',
      userPhoto: user?.photoUrl ?? '',
      text: text,
    );

    if (!mounted) return;
    
    if (success) {
      _controller.clear();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('فشل إرسال التعليق')));
    }
    setState(() => _isSending = false);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      appBar: AppBar(
        title: const Text('التعليقات', style: TextStyle(color: Colors.white)),
        backgroundColor: const Color(0xFF0A0A0F),
        elevation: 0,
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<List<CommentModel>>(
              stream: _firestore.getComments(widget.videoId),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
                final comments = snapshot.data!;
                if (comments.isEmpty) return const Center(child: Text('ما في تعليقات، كن الأول!', style: TextStyle(color: Colors.white54)));

                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: comments.length,
                  itemBuilder: (context, i) {
                    final c = comments[i];
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 16),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CircleAvatar(
                            backgroundImage: c.userPhoto != null && c.userPhoto!.isNotEmpty ? NetworkImage(c.userPhoto!) : null,
                            child: c.userPhoto == null || c.userPhoto!.isEmpty ? const Icon(Icons.person) : null,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(c.username, style: const TextStyle(color: Colors.white54, fontSize: 12, fontWeight: FontWeight.bold)),
                                const SizedBox(height: 4),
                                Text(c.text, style: const TextStyle(color: Colors.white, fontSize: 14)),
                                const SizedBox(height: 4),
                                Text(DateFormat('hh:mm a').format(c.createdAt), style: const TextStyle(color: Colors.white24, fontSize: 10)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: 'اكتب تعليق...',
                      hintStyle: const TextStyle(color: Colors.white54),
                      filled: true,
                      fillColor: const Color(0xFF1A1A2E),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: _isSending
                      ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.send, color: Colors.white),
                  onPressed: _isSending ? null : _send,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}