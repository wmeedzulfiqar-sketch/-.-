// lib/utils/permissions.dart
import 'package:permission_handler/permission_handler.dart';

class AppPermissions {
  // طلب صلاحية الكاميرا
  static Future<bool> requestCamera() async {
    final status = await Permission.camera.request();
    return status.isGranted;
  }

  // طلب صلاحية المايك
  static Future<bool> requestMicrophone() async {
    final status = await Permission.microphone.request();
    return status.isGranted;
  }

  // طلب صلاحية الصور
  static Future<bool> requestPhotos() async {
    final status = await Permission.photos.request();
    return status.isGranted;
  }

  // طلب كل الصلاحيات (للمكالمات والبث)
  static Future<bool> requestCallPermissions() async {
    final camera = await Permission.camera.request();
    final mic = await Permission.microphone.request();
    return camera.isGranted && mic.isGranted;
  }
}