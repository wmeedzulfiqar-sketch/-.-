// lib/screens/call_screen.dart
import 'package:flutter/material.dart';
import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import '../utils/constants.dart';

class CallScreen extends StatefulWidget {
  final String otherId;
  final String otherName;
  final bool isVideo;
  const CallScreen({super.key, required this.otherId, required this.otherName, required this.isVideo});

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  late RtcEngine _engine;
  bool _joined = false;
  bool _muted = false;
  bool _cameraOff = false;

  @override
  void initState() {
    super.initState();
    _initAgora();
  }

  Future<void> _initAgora() async {
    _engine = createAgoraRtcEngine();
    await _engine.initialize(const RtcEngineContext(appId: AppConstants.agoraAppId));

    _engine.registerEventHandler(RtcEngineEventHandler(
      onJoinChannelSuccess: (conn, elapsed) {
        if (mounted) setState(() => _joined = true);
      },
    ));

    await _engine.enableVideo();
    if (widget.isVideo) await _engine.startPreview();

    await _engine.joinChannel(
      token: '', // للاختبار
      channelId: 'call_${widget.otherId}',
      uid: 0,
      options: const ChannelMediaOptions(),
    );
  }

  @override
  void dispose() {
    _engine.leaveChannel();
    _engine.release();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          if (widget.isVideo && _joined)
            AgoraVideoView(
              controller: VideoViewController(
                rtcEngine: _engine,
                canvas: const VideoCanvas(uid: 0),
              ),
            )
          else
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircleAvatar(radius: 60, child: Text(widget.otherName[0], style: const TextStyle(fontSize: 48))),
                  const SizedBox(height: 16),
                  Text(widget.otherName, style: const TextStyle(fontSize: 24, color: Colors.white)),
                  const SizedBox(height: 8),
                  Text(_joined ? 'متصل' : 'جاري الاتصال...', style: const TextStyle(color: Colors.white54)),
                ],
              ),
            ),
          Positioned(
            bottom: 40, left: 0, right: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _ctrlBtn(icon: _muted ? Icons.mic_off : Icons.mic, onTap: () {
                  setState(() => _muted = !_muted);
                  _engine.muteLocalAudioStream(_muted);
                }),
                if (widget.isVideo)
                  _ctrlBtn(icon: _cameraOff ? Icons.videocam_off : Icons.videocam, onTap: () {
                    setState(() => _cameraOff = !_cameraOff);
                    _engine.muteLocalVideoStream(_cameraOff);
                  }),
                _ctrlBtn(icon: Icons.call_end, color: Colors.red, onTap: () => Navigator.pop(context)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _ctrlBtn({required IconData icon, required VoidCallback onTap, Color color = Colors.white}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 60, height: 60,
        decoration: BoxDecoration(color: color.withOpacity(0.3), shape: BoxShape.circle),
        child: Icon(icon, color: color, size: 30),
      ),
    );
  }
}