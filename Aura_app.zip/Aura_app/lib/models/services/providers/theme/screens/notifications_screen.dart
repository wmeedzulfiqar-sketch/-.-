// lib/screens/notifications_screen.dart
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/notification_service.dart';
import '../services/auth_service.dart';
import '../models/notification_model.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  final _service = NotificationService();
  final _uid = AuthService().currentUser?.uid ?? '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      appBar: AppBar(
        title: const Text('الإشعارات', style: TextStyle(color: Colors.white)),
        backgroundColor: const Color(0xFF0A0A0F),
        actions: [
          TextButton(
            onPressed: () => _service.markAllRead(_uid),
            child: const Text('قراءة الكل', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
      body: StreamBuilder<List<AppNotification>>(
        stream: _service.getUserNotifications(_uid),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final notifs = snapshot.data!;
          if (notifs.isEmpty) return const Center(child: Text('ما في إشعارات', style: TextStyle(color: Colors.white54)));

          return ListView.builder(
            itemCount: notifs.length,
            itemBuilder: (context, i) {
              final n = notifs[i];
              return ListTile(
                leading: CircleAvatar(
                  backgroundImage: n.actorPhoto.isNotEmpty ? NetworkImage(n.actorPhoto) : null,
                  child: n.actorPhoto.isEmpty ? const Icon(Icons.person) : null,
                ),
                title: Text(_getText(n), style: TextStyle(fontWeight: n.read ? FontWeight.normal : FontWeight.bold, color: Colors.white)),
                subtitle: Text(DateFormat('hh:mm a').format(n.createdAt), style: const TextStyle(color: Colors.white54)),
                trailing: n.videoThumb != null
                    ? ClipRRect(borderRadius: BorderRadius.circular(4), child: Image.network(n.videoThumb!, width: 40, height: 50, fit: BoxFit.cover))
                    : null,
                onTap: () => _service.markRead(n.id),
              );
            },
          );
        },
      ),
    );
  }

  String _getText(AppNotification n) {
    switch (n.type) {
      case 'follow': return '${n.actorName} بدأ متابعتك';
      case 'like': return '${n.actorName} أعجب بفيديوك';
      case 'comment': return '${n.actorName} علق: ${n.text}';
      default: return 'إشعار جديد';
    }
  }
}