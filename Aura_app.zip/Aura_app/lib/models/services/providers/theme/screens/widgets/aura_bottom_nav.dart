// lib/widgets/aura_bottom_nav.dart
import 'dart:ui';
import 'package:flutter/material.dart';

class AuraBottomNav extends StatefulWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;
  final VoidCallback onUploadTap;

  const AuraBottomNav({
    super.key,
    required this.currentIndex,
    required this.onTap,
    required this.onUploadTap,
  });

  @override
  State<AuraBottomNav> createState() => _AuraBottomNavState();
}

class _AuraBottomNavState extends State<AuraBottomNav>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _slideAnim;
  int _previousIndex = 0;

  final _items = const [
    _NavItem(icon: Icons.home_outlined, activeIcon: Icons.home, label: 'الرئيسية'),
    _NavItem(icon: Icons.search, activeIcon: Icons.search, label: 'اكتشف'),
    _NavItem(icon: Icons.add, activeIcon: Icons.add, label: 'رفع', isCenter: true),
    _NavItem(icon: Icons.chat_bubble_outline, activeIcon: Icons.chat_bubble, label: 'الرسائل'),
    _NavItem(icon: Icons.person_outline, activeIcon: Icons.person, label: 'حسابي'),
  ];

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _slideAnim = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic),
    );
    _controller.forward();
    _previousIndex = widget.currentIndex;
  }

  @override
  void didUpdateWidget(covariant AuraBottomNav oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.currentIndex != widget.currentIndex) {
      _previousIndex = oldWidget.currentIndex;
      _controller.reset();
      _controller.forward();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final itemWidth = screenWidth / _items.length;

    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
      height: 72,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF667EEA).withOpacity(0.25),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  const Color(0xFF667EEA).withOpacity(0.95),
                  const Color(0xFF764BA2).withOpacity(0.95),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(
                color: Colors.white.withOpacity(0.15),
                width: 1,
              ),
            ),
            child: Stack(
              children: [
                AnimatedBuilder(
                  animation: _slideAnim,
                  builder: (context, child) {
                    final fromX = _previousIndex * itemWidth + (itemWidth - 48) / 2;
                    final toX = widget.currentIndex * itemWidth + (itemWidth - 48) / 2;
                    final currentX = fromX + (toX - fromX) * _slideAnim.value;
                    return Positioned(
                      left: currentX,
                      top: 12,
                      child: Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.25),
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.white.withOpacity(0.15),
                              blurRadius: 12,
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
                Row(
                  children: List.generate(_items.length, (i) {
                    final item = _items[i];
                    final isActive = i == widget.currentIndex;

                    return Expanded(
                      child: GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: () {
                          if (item.isCenter) {
                            widget.onUploadTap();
                          } else {
                            widget.onTap(i);
                          }
                        },
                        child: Center(
                          child: AnimatedScale(
                            scale: isActive ? 1.1 : 1.0,
                            duration: const Duration(milliseconds: 300),
                            child: item.isCenter
                                ? _buildCenterButton(item, isActive)
                                : _buildNavItem(item, isActive),
                          ),
                        ),
                      ),
                    );
                  }),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(_NavItem item, bool isActive) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(
          isActive ? item.activeIcon : item.icon,
          color: Colors.white.withOpacity(isActive ? 1.0 : 0.7),
          size: 26,
        ),
        const SizedBox(height: 4),
        Text(
          item.label,
          style: TextStyle(
            color: Colors.white.withOpacity(isActive ? 1.0 : 0.7),
            fontSize: 10,
            fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ],
    );
  }

  Widget _buildCenterButton(_NavItem item, bool isActive) {
    return Container(
      width: 48,
      height: 48,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: const Icon(
        Icons.add,
        color: Color(0xFF667EEA),
        size: 28,
      ),
    );
  }
}

class _NavItem {
  final IconData icon;
  final IconData activeIcon;
  final String label;
  final bool isCenter;

  const _NavItem({
    required this.icon,
    required this.activeIcon,
    required this.label,
    this.isCenter = false,
  });
}