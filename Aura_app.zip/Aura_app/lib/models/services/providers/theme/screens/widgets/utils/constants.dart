// lib/utils/constants.dart
// الثوابت الأساسية للتطبيق

class AppConstants {
  // ─── معلومات التطبيق ───
  static const String appName = 'Aura';
  static const String appVersion = '1.0.0';
  
  // ─── Agora (للمكالمات والبث) ───
  // سجل في agora.io وحط الـ App ID هنا
  static const String agoraAppId = 'YOUR_AGORA_APP_ID_HERE';
  
  // ─── شروط البث المباشر ───
  static const int minFollowersForLive = 50;
  
  // ─── حدود الفيديو والرسائل ───
  static const int maxVideoDurationSec = 180; // 3 دقائق
  static const int maxCaptionLength = 2200;
  static const int maxCommentLength = 500;
  
  // ─── Firestore Collections ───
  static const String usersCollection = 'users';
  static const String videosCollection = 'videos';
  static const String chatsCollection = 'chats';
  static const String notificationsCollection = 'notifications';
  static const String trendsCollection = 'trends';
  
  // ─── روابط ───
  static const String shareBaseUrl = 'https://aura.app/video/';
}