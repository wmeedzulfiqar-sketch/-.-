// lib/screens/home_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/user_provider.dart';
import '../providers/feed_provider.dart';
import '../widgets/video_player_widget.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  late FeedProvider _feedProvider;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    
    // جلب الفيديوهات عند فتح الشاشة
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _feedProvider = Provider.of<FeedProvider>(context, listen: false);
      _feedProvider.listenToForYouFeed();
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final feedProvider = context.watch<FeedProvider>();
    final userProvider = context.watch<UserProvider>();
    final uid = userProvider.user?.uid ?? '';

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            // شريط التبويبات (لك / متابعة)
            Container(
              color: Colors.black,
              child: TabBar(
                controller: _tabController,
                indicatorColor: Colors.white,
                indicatorWeight: 2,
                labelColor: Colors.white,
                unselectedLabelColor: Colors.white54,
                labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                tabs: const [
                  Tab(text: 'متابعة'),
                  Tab(text: 'لك'),
                ],
                onTap: (index) {
                  if (index == 0) {
                    feedProvider.listenToFollowingFeed(uid);
                  } else {
                    feedProvider.listenToForYouFeed();
                  }
                },
              ),
            ),

            // محتوى التبويبات
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  // صفحة المتابعة (نفس المنطق، بس نجيب فيديوهات المتابعين)
                  _buildFeed(feedProvider),
                  // صفحة "لك"
                  _buildFeed(feedProvider),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFeed(FeedProvider provider) {
    if (provider.isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (provider.error != null) {
      return Center(child: Text(provider.error!, style: const TextStyle(color: Colors.white)));
    }

    if (provider.videos.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.video_library_outlined, size: 60, color: Colors.white24),
            SizedBox(height: 16),
            Text('ما في فيديوهات حالياً', style: TextStyle(color: Colors.white54)),
          ],
        ),
      );
    }

    return PageView.builder(
      scrollDirection: Axis.vertical,
      itemCount: provider.videos.length,
      itemBuilder: (context, index) {
        return VideoPlayerWidget(video: provider.videos[index]);
      },
    );
  }
}