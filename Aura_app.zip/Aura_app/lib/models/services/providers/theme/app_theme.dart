// lib/theme/app_theme.dart
// ملف الثيم الأساسي — يحتوي على الألوان وبناء الثيم الليلي والنهاري

import 'package:flutter/material.dart';

class AppTheme {
  // ─── الألوان الأساسية اللي المستخدم يقدر يختار منها ───
  static const List<Color> primaryColors = [
    Color(0xFF667EEA), // أزرق بنفسجي (افتراضي)
    Color(0xFFFE2C55), // أحمر تيك توك
    Color(0xFF00D4FF), // سماوي
    Color(0xFF10B981), // أخضر
    Color(0xFFF59E0B), // برتقالي
    Color(0xFF8B5CF6), // بنفسجي
    Color(0xFFEC4899), // وردي
    Color(0xFF06B6D4), // تركواز
    Color(0xFFEF4444), // أحمر داكن
    Color(0xFF84CC16), // ليموني
  ];

  // ─── أسماء الألوان (تظهر في الإعدادات) ───
  static const List<String> colorNames = [
    'أزرق بنفسجي', 'أحمر', 'سماوي', 'أخضر', 'برتقالي',
    'بنفسجي', 'وردي', 'تركواز', 'أحمر داكن', 'ليموني',
  ];

  // ═══════════════════════════════════════════════════════════════════
  // الثيم الفاتح (النهاري)
  // ═══════════════════════════════════════════════════════════════════
  static ThemeData light(Color primary) => ThemeData(
    brightness: Brightness.light,
    scaffoldBackgroundColor: Colors.white,
    primaryColor: primary,
    colorScheme: ColorScheme.light(
      primary: primary,
      secondary: primary,
      surface: Colors.grey[100]!,
    ),
    // fontFamily: 'Tajawal', // فعّلها إذا ضفت الخط في assets
    useMaterial3: true,
    appBarTheme: AppBarTheme(
      backgroundColor: Colors.white,
      foregroundColor: Colors.black,
      elevation: 0,
    ),
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      backgroundColor: Colors.white,
      selectedItemColor: primary,
      unselectedItemColor: Colors.grey,
    ),
  );

  // ═══════════════════════════════════════════════════════════════════
  // الثيم الداكن (الليلي)
  // ═══════════════════════════════════════════════════════════════════
  static ThemeData dark(Color primary) => ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: const Color(0xFF0A0A0F), // أسود مزرق
    primaryColor: primary,
    colorScheme: ColorScheme.dark(
      primary: primary,
      secondary: primary,
      surface: const Color(0xFF1A1A2E), // لون البطاقات
    ),
    // fontFamily: 'Tajawal',
    useMaterial3: true,
    appBarTheme: const AppBarTheme(
      backgroundColor: Color(0xFF0A0A0F),
      foregroundColor: Colors.white,
      elevation: 0,
    ),
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      backgroundColor: const Color(0xFF0A0A0F),
      selectedItemColor: primary,
      unselectedItemColor: Colors.white54,
    ),
  );
}