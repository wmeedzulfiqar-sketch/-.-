// lib/theme/colors.dart
import 'package:flutter/material.dart';

class AppColors {
  // خلفيات
  static const Color darkBg = Color(0xFF0A0A0F);
  static const Color darkSurface = Color(0xFF1A1A2E);
  static const Color lightBg = Colors.white;
  static const Color lightSurface = Color(0xFFF5F5F5);
  
  // نصوص
  static const Color textPrimary = Color(0xFFE6E3F0);
  static const Color textSecondary = Color(0xFF8F88A8);
  static const Color textDark = Color(0xFF1A1A2E);
  
  // حالات
  static const Color like = Color(0xFFFE2C55);
  static const Color save = Color(0xFFFFD700);
  static const Color success = Color(0xFF10B981);
  static const Color error = Color(0xFFEF4444);
}