// lib/providers/feed_provider.dart
import 'package:flutter/material.dart';
import '../models/video_model.dart';
import '../services/firestore_service.dart';

class FeedProvider extends ChangeNotifier {
  final FirestoreService _firestoreService = FirestoreService();
  
  List<VideoModel> _videos = [];
  bool _isLoading = true;
  String? _error;

  List<VideoModel> get videos => _videos;
  bool get isLoading => _isLoading;
  String? get error => _error;

  // 1. جلب فيديوهات "لك" (الخوارزمية)
  void listenToForYouFeed() {
    _isLoading = true;
    _error = null;
    notifyListeners();

    _firestoreService.getForYouFeed().listen(
      (vids) {
        _videos = vids;
        _isLoading = false;
        notifyListeners();
      },
      onError: (e) {
        _error = "حدث خطأ أثناء جلب الفيديوهات";
        _isLoading = false;
        notifyListeners();
      },
    );
  }

  // 2. جلب فيديوهات المتابعين
  void listenToFollowingFeed(String userId) {
    _isLoading = true;
    notifyListeners();

    _firestoreService.getFollowingFeed(userId).listen(
      (vids) {
        _videos = vids;
        _isLoading = false;
        notifyListeners();
      },
      onError: (e) {
        _error = "حدث خطأ أثناء جلب الفيديوهات";
        _isLoading = false;
        notifyListeners();
      },
    );
  }
}