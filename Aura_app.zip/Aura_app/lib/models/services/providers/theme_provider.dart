// lib/providers/theme_provider.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../theme/app_theme.dart';

class ThemeProvider extends ChangeNotifier {
  bool _isDark = true;
  Color _primaryColor = AppTheme.primaryColors[0];

  bool get isDark => _isDark;
  Color get primaryColor => _primaryColor;

  // تحميل الإعدادات عند بدء التطبيق
  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    _isDark = prefs.getBool('theme_dark') ?? true;
    final idx = prefs.getInt('theme_color') ?? 0;
    _primaryColor = AppTheme.primaryColors[idx];
    notifyListeners();
  }

  // تغيير الوضع الليلي
  Future<void> toggleDark() async {
    _isDark = !_isDark;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('theme_dark', _isDark);
    notifyListeners();
  }

  // تغيير اللون الأساسي
  Future<void> setPrimaryColor(int index) async {
    _primaryColor = AppTheme.primaryColors[index];
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('theme_color', index);
    notifyListeners();
  }

  // بناء الثيم
  ThemeData get theme => _isDark ? AppTheme.dark(_primaryColor) : AppTheme.light(_primaryColor);
}