// lib/providers/user_provider.dart
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/user_model.dart';
import '../services/auth_service.dart';

class UserProvider extends ChangeNotifier {
  final AuthService _authService = AuthService();
  UserModel? _user;
  bool _isLoading = true;

  UserModel? get user => _user;
  bool get isLoading => _isLoading;
  bool get isLoggedIn => _user != null;

  // مراقبة حالة تسجيل الدخول
  void listenToAuthState() {
    _authService.authStateChanges.listen((User? firebaseUser) async {
      if (firebaseUser != null) {
        _isLoading = true;
        notifyListeners();
        _user = await _authService.getUser(firebaseUser.uid);
      } else {
        _user = null;
      }
      _isLoading = false;
      notifyListeners();
    });
  }

  // تحديث بيانات المستخدم
  Future<void> refreshUser() async {
    if (_authService.currentUser != null) {
      _user = await _authService.getUser(_authService.currentUser!.uid);
      notifyListeners();
    }
  }
}