// lib/services/auth_service.dart
// خدمة المصادقة (تسجيل، دخول، خروج، وجوجل)
// تستخدم Firebase Auth

import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../models/user_model.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // المستخدم الحالي
  User? get currentUser => _auth.currentUser;

  // مراقبة حالة تسجيل الدخول
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // ─── تسجيل حساب جديد ───
  Future<String?> signUp({
    required String email,
    required String password,
    required String username,
  }) async {
    try {
      final cred = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      // إنشاء وثيقة المستخدم في Firestore
      final user = UserModel(
        uid: cred.user!.uid,
        username: username,
        email: email,
      );
      await _firestore.collection('users').doc(cred.user!.uid).set(user.toMap());
      
      return null; // نجاح
    } on FirebaseAuthException catch (e) {
      return _mapAuthError(e.code);
    } catch (e) {
      return 'حدث خطأ غير متوقع. حاول مرة ثانية.';
    }
  }

  // ─── تسجيل الدخول ───
  Future<String?> signIn({
    required String email,
    required String password,
  }) async {
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      return null;
    } on FirebaseAuthException catch (e) {
      return _mapAuthError(e.code);
    } catch (e) {
      return 'حدث خطأ غير متوقع. حاول مرة ثانية.';
    }
  }

  // ─── تسجيل الدخول بجوجل ───
  Future<String?> signInWithGoogle() async {
    try {
      final googleSignIn = GoogleSignIn();
      final googleUser = await googleSignIn.signIn();
      
      if (googleUser == null) return 'تم إلغاء تسجيل الدخول';
      
      final googleAuth = await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );
      
      final userCred = await _auth.signInWithCredential(credential);
      
      // إذا كان مستخدم جديد، أنشئ وثيقة له
      final doc = await _firestore.collection('users').doc(userCred.user!.uid).get();
      if (!doc.exists) {
        final user = UserModel(
          uid: userCred.user!.uid,
          username: userCred.user!.displayName ?? 'user_${userCred.user!.uid.substring(0, 5)}',
          email: userCred.user!.email ?? '',
          photoUrl: userCred.user!.photoURL,
        );
        await _firestore.collection('users').doc(userCred.user!.uid).set(user.toMap());
      }
      
      return null;
    } catch (e) {
      return 'فشل تسجيل الدخول بجوجل. تأكد من اتصالك.';
    }
  }

  // ─── تسجيل الخروج ───
  Future<void> signOut() async {
    try {
      await GoogleSignIn().signOut(); // جوجل
      await _auth.signOut();          // فيربيس
    } catch (e) {
      // تجاهل الخطأ
    }
  }

  // ─── جلب بيانات المستخدم ───
  Future<UserModel?> getUser(String uid) async {
    try {
      final doc = await _firestore.collection('users').doc(uid).get();
      if (doc.exists && doc.data() != null) {
        return UserModel.fromMap(doc.data()!);
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  // ─── ترجمة أخطاء Firebase إلى رسائل عربية ───
  String _mapAuthError(String code) {
    switch (code) {
      case 'email-already-in-use':
        return 'هذا الإيميل مستخدم من قبل.';
      case 'invalid-email':
        return 'صيغة الإيميل غير صحيحة.';
      case 'weak-password':
        return 'كلمة المرور ضعيفة جداً (6 أحرف على الأقل).';
      case 'user-not-found':
        return 'لا يوجد حساب بهذا الإيميل.';
      case 'wrong-password':
        return 'كلمة المرور غير صحيحة.';
      case 'too-many-requests':
        return 'محاولات كثيرة جداً. حاول لاحقاً.';
      case 'network-request-failed':
        return 'تأكد من اتصالك بالإنترنت.';
      default:
        return 'خطأ في المصادقة: $code';
    }
  }
}