// lib/services/trends_service.dart
// خدمة الترندات — تقرأ من وثيقة محسوبة مسبقاً من Cloud Function
// (آمنة من ناحية التكلفة، لا تقرأ كل الفيديوهات)

import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/video_model.dart';

class TrendsService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // ═══════════════════════════════════════════════════════════════════
  // 1. جلب الترندات (اللي حسبتها Cloud Function)
  // ═══════════════════════════════════════════════════════════════════
  Stream<List<Map<String, dynamic>>> getTrends() {
    return _db
        .collection('trends')
        .doc('current')
        .snapshots()
        .map((doc) {
      if (!doc.exists) return [];
      final data = doc.data();
      if (data == null) return [];
      
      final tags = (data['tags'] as List<dynamic>?) ?? [];
      return tags.map((t) => t as Map<String, dynamic>).toList();
    });
  }

  // ═══════════════════════════════════════════════════════════════════
  // 2. جلب فيديوهات هاشتاق معين (عشان لما المستخدم يضغط على ترند)
  // ═══════════════════════════════════════════════════════════════════
  Future<List<VideoModel>> getVideosByHashtag(String tag) async {
    try {
      final snap = await _db
          .collection('videos')
          .orderBy('createdAt', descending: true)
          .limit(100) // نحدد العدد عشان الأداء
          .get();
          
      return snap.docs
          .map((d) => VideoModel.fromMap(d.data()))
          .where((v) => v.caption.toLowerCase().contains('#$tag'.toLowerCase()))
          .toList();
    } catch (e) {
      return [];
    }
  }
}