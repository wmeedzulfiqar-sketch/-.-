// lib/services/chat_service.dart
// خدمة المحادثات — إرسال النصوص، البصمات الصوتية، وجلب قائمة الدردشات

import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/message_model.dart';

class ChatService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // ─── توليد معرف فريد للمحادثة بين شخصين (عشان ما تتكرر) ───
  // نرتب الآي دي أبجدياً عشان دايماً يطلع نفس المعرف سواء أرسلت أنا أو هو
  String chatId(String a, String b) {
    final sorted = [a, b]..sort();
    return sorted.join('_');
  }

  // ═══════════════════════════════════════════════════════════════════
  // 1. جلب الرسائل بيني وبين شخص ثاني
  // ═══════════════════════════════════════════════════════════════════
  Stream<List<MessageModel>> getMessages(String a, String b) {
    final id = chatId(a, b);
    return _db
        .collection('chats')
        .doc(id)
        .collection('messages')
        .orderBy('createdAt', descending: false) // الأقدم فوق
        .snapshots()
        .map((s) => s.docs.map((d) => MessageModel.fromMap(d.data())).toList());
  }

  // ═══════════════════════════════════════════════════════════════════
  // 2. إرسال رسالة نصية
  // ═══════════════════════════════════════════════════════════════════
  Future<bool> sendText(String sender, String receiver, String text) async {
    try {
      final id = chatId(sender, receiver);
      final msgId = _db.collection('chats').doc(id).collection('messages').doc().id;
      
      final msg = MessageModel(
        id: msgId,
        senderId: sender,
        receiverId: receiver,
        type: 'text',
        content: text,
        createdAt: DateTime.now(),
      );

      await _db.collection('chats').doc(id).collection('messages').doc(msgId).set(msg.toMap());
      
      // تحديث معلومات المحادثة الأساسية (عشان تظهر في قائمة الرسائل)
      await _db.collection('chats').doc(id).set({
        'lastMessage': text,
        'lastAt': DateTime.now().toIso8601String(),
        'users': [sender, receiver],
      });
      
      return true;
    } catch (e) {
      return false; // فشل الإرسال
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // 3. إرسال بصمة صوتية
  // ═══════════════════════════════════════════════════════════════════
  Future<bool> sendVoice(String sender, String receiver, String url, int duration) async {
    try {
      final id = chatId(sender, receiver);
      final msgId = _db.collection('chats').doc(id).collection('messages').doc().id;
      
      final msg = MessageModel(
        id: msgId,
        senderId: sender,
        receiverId: receiver,
        type: 'voice',
        content: url,
        duration: duration,
        createdAt: DateTime.now(),
      );

      await _db.collection('chats').doc(id).collection('messages').doc(msgId).set(msg.toMap());
      
      await _db.collection('chats').doc(id).set({
        'lastMessage': '🎤 رسالة صوتية',
        'lastAt': DateTime.now().toIso8601String(),
        'users': [sender, receiver],
      });
      
      return true;
    } catch (e) {
      return false;
    }
  }

  // ═══════════════════════════════════════════════════════════════════
  // 4. جلب قائمة المحادثات (للـ Inbox)
  // ═══════════════════════════════════════════════════════════════════
  Stream<List<Map<String, dynamic>>> getChatsList(String userId) {
    return _db
        .collection('chats')
        .where('users', arrayContains: userId)
        .orderBy('lastAt', descending: true)
        .snapshots()
        .map((s) => s.docs.map((d) => {'id': d.id, ...d.data()}).toList());
  }

  // ═══════════════════════════════════════════════════════════════════
  // 5. تحديث حالة القراءة (اختياري)
  // ═══════════════════════════════════════════════════════════════════
  Future<void> markMessagesAsSeen(String chatId, String userId) async {
    try {
      final snap = await _db
          .collection('chats')
          .doc(chatId)
          .collection('messages')
          .where('receiverId', isEqualTo: userId)
          .where('seen', isEqualTo: false)
          .get();

      final batch = _db.batch();
      for (final doc in snap.docs) {
        batch.update(doc.reference, {'seen': true});
      }
      await batch.commit();
    } catch (e) {}
  }
}