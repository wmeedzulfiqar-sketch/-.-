// lib/models/notification_model.dart
// نموذج الإشعار — يُخزن في collection('notifications')

class AppNotification {
  final String id;
  final String userId;      // المستلم
  final String actorId;     // اللي سوى الحدث
  final String actorName;
  final String actorPhoto;
  final String type;        // 'follow' | 'like' | 'comment' | 'mention'
  final String? videoId;
  final String? videoThumb;
  final String? text;
  final bool read;
  final DateTime createdAt;

  AppNotification({
    required this.id,
    required this.userId,
    required this.actorId,
    required this.actorName,
    required this.actorPhoto,
    required this.type,
    this.videoId,
    this.videoThumb,
    this.text,
    this.read = false,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'userId': userId,
      'actorId': actorId,
      'actorName': actorName,
      'actorPhoto': actorPhoto,
      'type': type,
      'videoId': videoId,
      'videoThumb': videoThumb,
      'text': text,
      'read': read,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory AppNotification.fromMap(Map<String, dynamic> map) {
    return AppNotification(
      id: map['id'] ?? '',
      userId: map['userId'] ?? '',
      actorId: map['actorId'] ?? '',
      actorName: map['actorName'] ?? '',
      actorPhoto: map['actorPhoto'] ?? '',
      type: map['type'] ?? '',
      videoId: map['videoId'],
      videoThumb: map['videoThumb'],
      text: map['text'],
      read: map['read'] ?? false,
      createdAt: DateTime.parse(map['createdAt']),
    );
  }
}