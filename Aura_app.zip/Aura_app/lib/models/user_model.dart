// lib/models/user_model.dart
// نموذج بيانات المستخدم — يُخزن في Firestore تحت collection('users')

class UserModel {
  final String uid;
  final String username;
  final String email;
  final String? photoUrl;
  final String? bio;
  final int followers;
  final int following;

  UserModel({
    required this.uid,
    required this.username,
    required this.email,
    this.photoUrl,
    this.bio,
    this.followers = 0,
    this.following = 0,
  });

  // يحول الكائن إلى Map عشان ينحفظ في Firestore
  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'username': username,
      'email': email,
      'photoUrl': photoUrl,
      'bio': bio,
      'followers': followers,
      'following': following,
    };
  }

  // ينشئ كائن من Map (لما نقرأ من Firestore)
  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      uid: map['uid'] ?? '',
      username: map['username'] ?? '',
      email: map['email'] ?? '',
      photoUrl: map['photoUrl'],
      bio: map['bio'],
      followers: map['followers'] ?? 0,
      following: map['following'] ?? 0,
    );
  }

  // لنسخ الكائن مع تعديل بعض الحقول
  UserModel copyWith({
    String? uid,
    String? username,
    String? email,
    String? photoUrl,
    String? bio,
    int? followers,
    int? following,
  }) {
    return UserModel(
      uid: uid ?? this.uid,
      username: username ?? this.username,
      email: email ?? this.email,
      photoUrl: photoUrl ?? this.photoUrl,
      bio: bio ?? this.bio,
      followers: followers ?? this.followers,
      following: following ?? this.following,
    );
  }
}