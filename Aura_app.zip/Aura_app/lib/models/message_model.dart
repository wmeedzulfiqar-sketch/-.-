// lib/models/message_model.dart
// نموذج الرسالة — يُخزن في chats/{chatId}/messages

class MessageModel {
  final String id;
  final String senderId;
  final String receiverId;
  final String type; // 'text' | 'voice' | 'image'
  final String content; // النص، أو رابط الملف
  final int duration;   // للصوت فقط (بالثواني)
  final DateTime createdAt;
  final bool seen;

  MessageModel({
    required this.id,
    required this.senderId,
    required this.receiverId,
    required this.type,
    required this.content,
    this.duration = 0,
    required this.createdAt,
    this.seen = false,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'senderId': senderId,
      'receiverId': receiverId,
      'type': type,
      'content': content,
      'duration': duration,
      'createdAt': createdAt.toIso8601String(),
      'seen': seen,
    };
  }

  factory MessageModel.fromMap(Map<String, dynamic> map) {
    return MessageModel(
      id: map['id'] ?? '',
      senderId: map['senderId'] ?? '',
      receiverId: map['receiverId'] ?? '',
      type: map['type'] ?? 'text',
      content: map['content'] ?? '',
      duration: map['duration'] ?? 0,
      createdAt: DateTime.parse(map['createdAt']),
      seen: map['seen'] ?? false,
    );
  }
}