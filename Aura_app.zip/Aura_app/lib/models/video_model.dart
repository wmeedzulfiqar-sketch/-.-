// lib/models/video_model.dart
// نموذج بيانات الفيديو — يُخزن في Firestore تحت collection('videos')

class VideoModel {
  final String id;
  final String userId;
  final String username;
  final String videoUrl;
  final String? thumbnailUrl;
  final String caption;
  final int likes;
  final int comments;
  final int shares;
  final int saves;
  final int views;
  final double score; // للخوارزمية
  final DateTime createdAt;

  VideoModel({
    required this.id,
    required this.userId,
    required this.username,
    required this.videoUrl,
    this.thumbnailUrl,
    required this.caption,
    this.likes = 0,
    this.comments = 0,
    this.shares = 0,
    this.saves = 0,
    this.views = 0,
    this.score = 0,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'userId': userId,
      'username': username,
      'videoUrl': videoUrl,
      'thumbnailUrl': thumbnailUrl,
      'caption': caption,
      'likes': likes,
      'comments': comments,
      'shares': shares,
      'saves': saves,
      'views': views,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory VideoModel.fromMap(Map<String, dynamic> map) {
    return VideoModel(
      id: map['id'] ?? '',
      userId: map['userId'] ?? '',
      username: map['username'] ?? '',
      videoUrl: map['videoUrl'] ?? '',
      thumbnailUrl: map['thumbnailUrl'],
      caption: map['caption'] ?? '',
      likes: map['likes'] ?? 0,
      comments: map['comments'] ?? 0,
      shares: map['shares'] ?? 0,
      saves: map['saves'] ?? 0,
      views: map['views'] ?? 0,
      score: (map['score'] ?? 0).toDouble(),
      createdAt: DateTime.parse(map['createdAt']),
    );
  }

  VideoModel copyWith({
    int? likes,
    int? comments,
    int? shares,
    int? saves,
    int? views,
    double? score,
  }) {
    return VideoModel(
      id: id,
      userId: userId,
      username: username,
      videoUrl: videoUrl,
      thumbnailUrl: thumbnailUrl,
      caption: caption,
      likes: likes ?? this.likes,
      comments: comments ?? this.comments,
      shares: shares ?? this.shares,
      saves: saves ?? this.saves,
      views: views ?? this.views,
      score: score ?? this.score,
      createdAt: createdAt,
    );
  }
}